import React from 'react'

export const AppContext = () => {
  return (
    <div>AppContext</div>
  )
}

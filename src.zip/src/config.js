module.exports = {
    APP_NAME: " - Discount Space",
    URL: "https://discounts-space.com/",
    SITE_URL: "https://discounts-space.com/",
    API_TOKEN: "10010110101001010"
}
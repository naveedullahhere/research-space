import React from 'react'

export const Error = () => {
    return (
        <div className="col-12 py-3">
            <h1 className="heading fs-3">Something Went Wrong!</h1>
        </div>
    )
}

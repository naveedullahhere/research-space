import React from 'react'

export const Footer3 = () => {
    return (
        <div>Footer3</div>
    )
}

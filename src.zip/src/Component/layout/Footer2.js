import React from 'react'

export const Footer2 = () => {
    return (
        <>

        </>
    )
}
